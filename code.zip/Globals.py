# DESCRIPTION: This file contains some global variables.

nUsers = 10000
nItems = 1000

k = 1000
outputIdx = ''
warmStart = False
lrate = 0.001
predict = ''
modelIdx = ''
step = 0
fixed = True
dataIdx = ''
l2 = 0.02